class GradedActivity
{
protected:
    char letter;        // To hold the letter grade
    double score;       // To hold the numeric score
    void determineGrade(); // Determines the letter grade

public:
    // Default constructor
    GradedActivity()
    { letter = ' '; score = 0.0; }

    // Mutator functions
    void determineGrade(double s)
    {
        if (s < 60) {letter = 'F';}
        else if (s >= 60 && s < 70) {letter = 'D';}
        else if (s >= 70 && s < 80) {letter = 'C';}
        else if (s >= 80 && s < 90) {letter = 'B';}
        else letter = 'A';
    }

    void setScore(double s)
    { 
        score = s;
        determineGrade(s);
    }

    // Accessor functions
    double getScore() const
    { return score; }

    char getLetterGrade() const
    { return letter; }
};